-- ui/multiplayer_menu.lua
local menu_visible = false

function ShowMultiplayerMenu()
    if menu_visible then
        HideMultiplayerMenu()
    else
        menu_visible = true
        UI.ShowMultiplayerMenu()
    end
end

function HideMultiplayerMenu()
    menu_visible = false
    UI.HideMultiplayerMenu()
end

function HostGame()
    StartServer()
    ConnectToServer("127.0.0.1", 25565)
    HideMultiplayerMenu()
end

function JoinGame()
    local ip = UI.GetElementText("ip_input")
    ConnectToServer(ip, 25565)
    HideMultiplayerMenu()
end

function UpdateStatusText(text)
    UI.SetElementText("status_text", text)
end

function UpdatePlayerList(players)
    UI.ClearList("player_list")
    for id, player in pairs(players) do
        UI.AddToList("player_list", id .. " - " .. player.name)
    end
end