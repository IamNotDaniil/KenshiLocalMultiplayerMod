function CreateUDPSocket(port)
    local socket = Network.CreateUDPSocket()
    socket:Bind(port)
    return socket
end

function SendPacket(ip, port, packet_type, data)
    local packet = {
        type = packet_type,
        timestamp = GetTime(),
        data = data
    }
    Network.Send(ip, port, Serialize(packet))
end

function ReceivePacket()
    local raw_data = Network.Receive()
    return Deserialize(raw_data)
end