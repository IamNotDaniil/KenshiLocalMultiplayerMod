-- client.lua
local connected = false
local server_ip = "127.0.0.1"
local server_port = 25565
local socket = nil
local my_id = nil
local other_players = {}

function ConnectToServer(ip, port)
    server_ip = ip or server_ip
    server_port = port or server_port

    socket = CreateUDPSocket(0)
    my_id = GeneratePlayerID()

    local join_packet = {
        type = "JOIN",
        player_id = my_id,
        position = GetPlayerPosition(),
        character_data = ExportCharacterData()
    }

    SendPacket(socket, server_ip, server_port, join_packet)

    -- Ждем подтверждения от сервера
    local ack = WaitForPacket(socket, "JOIN_ACK", 5000)
    if ack then
        connected = true
        Print("Connected to server")
        StartSyncThread()
        StartReceiveThread()
    else
        Print("Failed to connect to server")
    end
end

function StartSyncThread()
    while connected do
        SendMovementData()
        Sleep(33)
    end
end

function StartReceiveThread()
    while connected do
        local packet = ReceivePacket(socket)
        if packet then
            HandlePacket(packet)
        end
    end
end

function HandlePacket(packet)
    if packet.type == "SYNC_POSITIONS" then
        for id, pos in pairs(packet.data) do
            if id ~= my_id then
                UpdateOtherPlayerPosition(id, pos.x, pos.y)
            end
        end
    elseif packet.type == "PLAYER_JOINED" then
        Print("Player joined: " .. packet.data)
    elseif packet.type == "CHAT_MESSAGE" then
        AddChatMessage(packet.data.player_id, packet.data.message)
    end
end

function SendMovementData()
    local x, y = GetPlayerPosition()
    local movement_packet = {
        type = "MOVEMENT",
        player_id = my_id,
        x = x,
        y = y
    }
    SendPacket(socket, server_ip, server_port, movement_packet)
end

function SendChatMessage(message)
    local chat_packet = {
        type = "CHAT",
        player_id = my_id,
        message = message
    }
    SendPacket(socket, server_ip, server_port, chat_packet)
end