-- init.lua (обновленная версия)
local MultiplayerMod = {
    initialized = false,
    version = "1.0"
}

function MultiplayerMod.Init()
    if MultiplayerMod.initialized then return end
    
    -- Загрузка зависимостей в правильном порядке
    require("scripts/network")
    require("scripts/ui_manager")  -- Добавлена эта строка
    require("scripts/keybinds")
    require("scripts/state_sync")
    require("scripts/chat_system")
    require("scripts/entity_manager")
    
    -- Инициализация систем
    InitializeNetwork()
    InitializeChatSystem()
    
    -- UI Manager инициализируется автоматически при загрузке игры
    -- через обработчик событий в ui_manager.lua
    
    CreateTimer("DelayedInit", 100, function()
        RegisterKeybinds()
        PrintToConsole("Multiplayer Mod " .. MultiplayerMod.version .. " initialized")
        PrintToChat("Multiplayer Mod ready - Press F6 for menu")
    end)
    
    MultiplayerMod.initialized = true
end

-- Автозагрузка при старте игры
CreateTimer("AutoInit", 5000, function()
    if IsGameLoaded() then
        MultiplayerMod.Init()
    end
end)