-- server.lua
local players = {}
local server_running = false
local socket = nil

function StartServer()
    server_running = true
    socket = CreateUDPSocket(25565)
    Print("Server started on port 25565")

    while server_running do
        local packet, ip, port = ReceivePacket(socket)
        if packet then
            HandlePacket(packet, ip, port)
        end
        BroadcastPlayerPositions()
        Sleep(33) -- Примерно 30 раз в секунду
    end
end

function HandlePacket(packet, ip, port)
    if packet.type == "JOIN" then
        local player_id = packet.player_id
        players[player_id] = {
            ip = ip,
            port = port,
            position = packet.position,
            character = packet.character_data
        }
        BroadcastToAll("PLAYER_JOINED", player_id)
        SendPacket(socket, ip, port, "JOIN_ACK", { assigned_id = player_id })
    elseif packet.type == "MOVEMENT" then
        local player_id = packet.player_id
        if players[player_id] then
            players[player_id].position = { x = packet.x, y = packet.y }
        end
    elseif packet.type == "CHAT" then
        BroadcastToAll("CHAT_MESSAGE", { player_id = packet.player_id, message = packet.message })
    end
end

function BroadcastToAll(packet_type, data)
    for id, player in pairs(players) do
        SendPacket(socket, player.ip, player.port, packet_type, data)
    end
end

function BroadcastPlayerPositions()
    local positions = {}
    for id, player in pairs(players) do
        positions[id] = player.position
    end
    BroadcastToAll("SYNC_POSITIONS", positions)
end