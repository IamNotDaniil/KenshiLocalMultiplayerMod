-- debug.lua
function DebugKeybinds()
    PrintToConsole("=== Keybind Debug ===")
    PrintToConsole("F6 bound: " .. tostring(Input.IsKeyBound("F6")))
    PrintToConsole("Menu exists: " .. tostring(UI.GetWindow("MultiplayerMenu") ~= nil))
    PrintToConsole("Game loaded: " .. tostring(IsGameLoaded()))
    PrintToConsole("Mod initialized: " .. tostring(IsModInitialized()))
end

-- Команда для проверки биндов в игре
RegisterConsoleCommand("debug_keys", DebugKeybinds)