-- entity_manager.lua
local EntityManager = {
    networked_entities = {},
    entity_id_counter = 1
}

function EntityManager.AssignNetworkID(entity)
    local network_id = EntityManager.entity_id_counter
    EntityManager.entity_id_counter = EntityManager.entity_id_counter + 1
    
    EntityManager.networked_entities[network_id] = {
        entity = entity,
        type = GetEntityType(entity),
        owner = nil,
        last_update = GetTime()
    }
    
    return network_id
end

function EntityManager.SyncEntityCreation(entity, creator_id)
    local network_id = EntityManager.AssignNetworkID(entity)
    EntityManager.networked_entities[network_id].owner = creator_id
    
    BroadcastToAllClients("ENTITY_CREATED", {
        network_id = network_id,
        entity_type = GetEntityType(entity),
        position = GetEntityPosition(entity),
        data = GetEntityData(entity),
        owner = creator_id
    })
    
    return network_id
end

function EntityManager.SyncEntityDestruction(network_id)
    if EntityManager.networked_entities[network_id] then
        BroadcastToAllClients("ENTITY_DESTROYED", {
            network_id = network_id
        })
        
        EntityManager.networked_entities[network_id] = nil
    end
end

function EntityManager.UpdateEntityState(network_id, new_state)
    if EntityManager.networked_entities[network_id] then
        EntityManager.networked_entities[network_id].last_update = GetTime()
        
        BroadcastToAllClients("ENTITY_UPDATED", {
            network_id = network_id,
            state = new_state
        })
    end
end

function EntityManager.GetEntityByNetworkID(network_id)
    return EntityManager.networked_entities[network_id]
end

function EntityManager.CleanupOrphanedEntities()
    local current_time = GetTime()
    local cleanup_threshold = 300000 -- 5 минут
    
    for network_id, entity_data in pairs(EntityManager.networked_entities) do
        if current_time - entity_data.last_update > cleanup_threshold then
            EntityManager.SyncEntityDestruction(network_id)
        end
    end
end