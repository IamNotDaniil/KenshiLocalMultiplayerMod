-- chat_system.lua
local ChatSystem = {
    messages = {},
    max_messages = 100
}

function ChatSystem.Initialize()
    RegisterNetworkHandler("CHAT_MESSAGE", ChatSystem.HandleChatMessage)
    CreateChatWindow()
end

function ChatSystem.HandleChatMessage(player_id, message_data)
    local message = {
        player_id = player_id,
        player_name = GetPlayerName(player_id),
        text = message_data.text,
        type = message_data.type or "global",
        timestamp = GetTime()
    }
    
    -- Добавить в историю
    table.insert(ChatSystem.messages, message)
    
    -- Ограничить размер истории
    if #ChatSystem.messages > ChatSystem.max_messages then
        table.remove(ChatSystem.messages, 1)
    end
    
    -- Отправить всем игрокам
    BroadcastToAllClients("CHAT_MESSAGE_RECEIVED", message)
    
    -- Отобразить в UI
    AddMessageToChatWindow(message)
end

function ChatSystem.SendMessage(player_id, text, message_type)
    local message_data = {
        text = string.sub(text, 1, 200), -- Ограничение длины
        type = message_type or "global"
    }
    
    SendToServer("CHAT_MESSAGE", message_data)
end

function ChatSystem.GetMessageHistory()
    return ChatSystem.messages
end

-- Инициализация чата
ChatSystem.Initialize()