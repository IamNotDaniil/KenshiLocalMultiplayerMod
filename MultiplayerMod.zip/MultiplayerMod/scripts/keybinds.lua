-- keybinds.lua
function InitializeMultiplayerMod()
    -- Регистрация горячих клавиш при загрузке мода
    RegisterKeybinds()
    CreateMenuSystem()
end

function RegisterKeybinds()
    -- Привязка F6 к функции открытия меню
    Input.BindKey("F6", "ToggleMultiplayerMenu")
    Input.BindKey("F7", "QuickConnect")
    Input.BindKey("F8", "HostGame")
    Input.BindKey("F9", "Disconnect", "Ctrl")
    Input.BindKey("Tab", "ShowPlayerList", "Shift")
    Input.BindKey("I", "SyncInventory", "Ctrl+Shift")
    Input.BindKey("T", "TeleportToPlayer", "Ctrl+Alt")
    Input.BindKey("Enter", "OpenChat")
    Input.BindKey("Escape", "CloseChat")
end

function ToggleMultiplayerMenu()
    if not IsInGame() then return end
    
    local menu = UI.GetWindow("MultiplayerMenu")
    if menu and menu:IsVisible() then
        menu:Hide()
    else
        ShowMultiplayerMenu()
    end
end

function ShowMultiplayerMenu()
    -- Создание меню если не существует
    if not UI.GetWindow("MultiplayerMenu") then
        UI.LoadLayout("ui/multiplayer_menu.xml")
    end
    
    local menu = UI.GetWindow("MultiplayerMenu")
    menu:Show()
    menu:BringToFront()
    
    -- Обновление статуса подключения
    UpdateConnectionStatus()
end

function UpdateConnectionStatus()
    local statusText = UI.GetWidget("status_text")
    if not statusText then return end
    
    if IsServerRunning() then
        statusText:SetText("Server Running - Port 25565")
        statusText:SetColor(0, 255, 0) -- Зеленый
    elseif IsConnected() then
        statusText:SetText("Connected to " .. GetServerIP())
        statusText:SetColor(0, 200, 255) -- Голубой
    else
        statusText:SetText("Disconnected")
        statusText:SetColor(255, 50, 50) -- Красный
    end
end

function HostGame()
    if IsServerRunning() then
        PrintToChat("Server is already running!")
        return
    end
    
    local success = StartMultiplayerServer()
    if success then
        PrintToChat("Server started successfully on port 25565")
        UpdateConnectionStatus()
    else
        PrintToChat("Failed to start server! Check port 25565")
    end
end

function JoinGame()
    local ipInput = UI.GetWidget("ip_input")
    if not ipInput then return end
    
    local ip = ipInput:GetText()
    if ip == "" then
        ip = "127.0.0.1"
    end
    
    ConnectToServer(ip, 25565)
end

function QuickConnect()
    local lastIP = Settings.GetString("last_server_ip", "127.0.0.1")
    ConnectToServer(lastIP, 25565)
end

-- Автоматическая инициализация при загрузке
CreateTimer("InitTimer", 2000, function() 
    InitializeMultiplayerMod()
    PrintToChat("Multiplayer Mod loaded - Press F6 for menu")
end)