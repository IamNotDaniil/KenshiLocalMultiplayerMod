function RegisterMultiplayerKeybinds()
    Input.RegisterAction("OpenMultiplayerMenu", function()
        if IsInGame() then
            ShowMultiplayerMenu()
        end
    end)
    
    Input.RegisterAction("QuickConnect", function()
        if IsInGame() then
            ConnectToLastServer()
        end
    end)
    
    Input.RegisterAction("HostGame", function()
        if IsInGame() and not IsServerRunning() then
            StartMultiplayerServer()
        end
    end)
    
    Input.RegisterAction("Disconnect", function()
        if IsConnected() then
            DisconnectFromServer()
        end
    end)
    
    Input.RegisterAction("PlayerList", function()
        if IsConnected() then
            TogglePlayerList()
        end
    end)
    
    Input.RegisterAction("SyncInventory", function()
        if IsConnected() then
            SyncInventoryWithServer()
        end
    end)
    
    Input.RegisterAction("TeleportToPlayer", function()
        if IsConnected() then
            ShowTeleportMenu()
        end
    end)
    
    Input.RegisterAction("OpenChat", function()
        if IsConnected() then
            OpenChatWindow()
        end
    end)
    
    Input.RegisterAction("CloseChat", function()
        if ChatIsOpen() then
            CloseChatWindow()
        end
    end)
    
    Input.RegisterAction("SendMessage", function()
        if ChatIsOpen() then
            SendChatMessage()
        end
    end)
end

-- Вызови эту функцию при инициализации мода
RegisterMultiplayerKeybinds()