-- ui_manager.lua
local UIManager = {
    windows = {},
    elements = {},
    initialized = false
}

function UIManager.Initialize()
    if UIManager.initialized then return end
    
    -- Загрузка UI layouts
    UIManager.LoadUILayouts()
    
    -- Регистрация обработчиков событий
    UIManager.RegisterEventHandlers()
    
    -- Создание системных элементов UI
    UIManager.CreateSystemUI()
    
    UIManager.initialized = true
    PrintToConsole("UI Manager initialized")
end

function UIManager.LoadUILayouts()
    -- Загрузка основного меню мультиплеера
    if not UI.LoadLayout("ui/multiplayer_menu.xml") then
        PrintToConsole("ERROR: Failed to load multiplayer_menu.xml")
        return false
    end
    
    -- Загрузка окна чата
    if not UI.LoadLayout("ui/chat_window.xml") then
        PrintToConsole("WARNING: Failed to load chat_window.xml")
    end
    
    -- Загрузка дополнительных UI элементов
    UIManager.LoadAdditionalUI()
    
    return true
end

function UIManager.LoadAdditionalUI()
    -- Динамическое создание элементов, если XML не загрузился
    if not UI.GetWindow("MultiplayerMenu") then
        UIManager.CreateMultiplayerMenu()
    end
    
    if not UI.GetWindow("ChatWindow") then
        UIManager.CreateChatWindow()
    end
end

function UIManager.CreateMultiplayerMenu()
    -- Создание главного меню программно
    local menu = UI.CreateWindow({
        name = "MultiplayerMenu",
        size = {450, 350},
        position = {500, 300},
        movable = true,
        visible = false,
        title = "Multiplayer Mod v1.0"
    })
    
    -- Группа подключения
    local connectionGroup = menu:CreateGroupBox({
        position = {10, 35},
        size = {430, 120},
        text = "Connection"
    })
    
    connectionGroup:CreateText({
        name = "status_label",
        text = "Status:",
        position = {15, 25},
        size = {80, 20}
    })
    
    connectionGroup:CreateText({
        name = "status_text", 
        text = "Disconnected",
        position = {100, 25},
        size = {200, 20},
        color = {255, 50, 50}
    })
    
    connectionGroup:CreateInput({
        name = "ip_input",
        text = "127.0.0.1", 
        position = {15, 55},
        size = {200, 25},
        tooltip = "Server IP Address"
    })
    
    connectionGroup:CreateButton({
        name = "host_button",
        text = "Host Game (F8)",
        position = {15, 90},
        size = {120, 30},
        onClick = "HostGame()"
    })
    
    connectionGroup:CreateButton({
        name = "join_button",
        text = "Join Game",
        position = {145, 90},
        size = {120, 30},
        onClick = "JoinGame()"
    })
    
    connectionGroup:CreateButton({
        name = "quick_button", 
        text = "Quick Connect (F7)",
        position = {275, 90},
        size = {120, 30},
        onClick = "QuickConnect()"
    })
    
    -- Группа игроков
    local playersGroup = menu:CreateGroupBox({
        position = {10, 165},
        size = {430, 140},
        text = "Players"
    })
    
    local playerList = playersGroup:CreateList({
        name = "player_list",
        position = {15, 25},
        size = {400, 80}
    })
    
    playerList:AddColumn("Player", 150)
    playerList:AddColumn("Ping", 80) 
    playerList:AddColumn("Status", 170)
    
    playersGroup:CreateButton({
        name = "refresh_button",
        text = "Refresh",
        position = {15, 110},
        size = {80, 25},
        onClick = "RefreshPlayerList()"
    })
    
    playersGroup:CreateButton({
        name = "kick_button",
        text = "Kick Player",
        position = {105, 110},
        size = {100, 25},
        onClick = "KickSelectedPlayer()",
        enabled = false
    })
    
    playersGroup:CreateButton({
        name = "teleport_button",
        text = "Teleport To", 
        position = {215, 110},
        size = {100, 25},
        onClick = "TeleportToSelected()",
        enabled = false
    })
    
    menu:CreateButton({
        name = "close_button",
        text = "Close (F6)",
        position = {350, 315},
        size = {90, 25},
        onClick = "CloseMultiplayerMenu()"
    })
    
    UIManager.windows.MultiplayerMenu = menu
    return menu
end

function UIManager.CreateChatWindow()
    local chatWindow = UI.CreateWindow({
        name = "ChatWindow",
        size = {400, 200},
        position = {10, 500},
        movable = true,
        visible = false
    })
    
    local scrollArea = chatWindow:CreateScrollArea({
        name = "chat_messages",
        position = {5, 5},
        size = {390, 160}
    })
    
    chatWindow:CreateInput({
        name = "chat_input",
        text = "",
        position = {5, 170},
        size = {390, 25},
        visible = false,
        maxLength = 200
    })
    
    UIManager.windows.ChatWindow = chatWindow
    return chatWindow
end

function UIManager.CreateSystemUI()
    -- Создание скрытых системных элементов
    UIManager.CreateConnectionStatus()
    UIManager.CreateNotificationSystem()
end

function UIManager.CreateConnectionStatus()
    -- Индикатор статуса подключения в углу экрана
    local statusIndicator = UI.CreateText({
        name = "connection_status",
        text = "MP: Offline",
        position = {10, 10},
        size = {120, 20},
        color = {255, 50, 50},
        visible = true
    })
    
    UIManager.elements.connectionStatus = statusIndicator
end

function UIManager.CreateNotificationSystem()
    -- Система уведомлений вверху экрана
    local notificationArea = UI.CreateContainer({
        name = "notification_area",
        position = {200, 10},
        size = {400, 100},
        visible = true
    })
    
    UIManager.elements.notificationArea = notificationArea
end

function UIManager.ShowMultiplayerMenu()
    local menu = UIManager.windows.MultiplayerMenu
    if not menu then
        menu = UIManager.CreateMultiplayerMenu()
    end
    
    if menu then
        menu:Show()
        menu:BringToFront()
        UIManager.UpdateConnectionStatus()
    else
        PrintToConsole("ERROR: Failed to create multiplayer menu")
    end
end

function UIManager.HideMultiplayerMenu()
    local menu = UIManager.windows.MultiplayerMenu
    if menu then
        menu:Hide()
    end
end

function UIManager.ToggleMultiplayerMenu()
    local menu = UIManager.windows.MultiplayerMenu
    if menu and menu:IsVisible() then
        UIManager.HideMultiplayerMenu()
    else
        UIManager.ShowMultiplayerMenu()
    end
end

function UIManager.UpdateConnectionStatus()
    local statusText = UI.GetWidget("status_text")
    local statusIndicator = UIManager.elements.connectionStatus
    
    if not statusText and not statusIndicator then return end
    
    local status, color, indicatorText
    
    if IsServerRunning() then
        status = "Server Running - Port 25565"
        color = {0, 255, 0}
        indicatorText = "MP: Hosting"
    elseif IsConnected() then
        status = "Connected to " .. GetServerIP()
        color = {0, 200, 255}
        indicatorText = "MP: Connected"
    else
        status = "Disconnected"
        color = {255, 50, 50}
        indicatorText = "MP: Offline"
    end
    
    if statusText then
        statusText:SetText(status)
        statusText:SetColor(color[1], color[2], color[3])
    end
    
    if statusIndicator then
        statusIndicator:SetText(indicatorText)
        statusIndicator:SetColor(color[1], color[2], color[3])
    end
end

function UIManager.ShowNotification(message, duration)
    duration = duration or 5000
    
    local notification = UIManager.elements.notificationArea:CreateText({
        text = message,
        position = {0, 0},
        size = {400, 25},
        color = {255, 255, 255}
    })
    
    -- Анимация появления
    notification:Animate("fade_in", 300)
    
    -- Автоматическое скрытие
    CreateTimer("HideNotification_" .. GetTime(), duration, function()
        notification:Animate("fade_out", 300, function()
            notification:Destroy()
        end)
    end)
end

function UIManager.RegisterEventHandlers()
    -- Обработчик изменения состояния подключения
    RegisterEventHandler("CONNECTION_CHANGED", function()
        UIManager.UpdateConnectionStatus()
    end)
    
    -- Обработчик получения сообщения чата
    RegisterEventHandler("CHAT_MESSAGE_RECEIVED", function(message)
        UIManager.AddChatMessage(message)
    end)
    
    -- Обработчик обновления списка игроков
    RegisterEventHandler("PLAYER_LIST_UPDATED", function(players)
        UIManager.UpdatePlayerList(players)
    end)
end

function UIManager.AddChatMessage(message)
    local chatWindow = UIManager.windows.ChatWindow
    if not chatWindow then return end
    
    local scrollArea = chatWindow:GetWidget("chat_messages")
    if not scrollArea then return end
    
    local messageElement = scrollArea:CreateText({
        text = "[" .. FormatTime(message.timestamp) .. "] " .. message.player_name .. ": " .. message.text,
        position = {0, #scrollArea.children * 20},
        size = {380, 20}
    })
    
    -- Прокрутка к новому сообщению
    scrollArea:ScrollToBottom()
end

function UIManager.UpdatePlayerList(players)
    local playerList = UI.GetWidget("player_list")
    if not playerList then return end
    
    playerList:Clear()
    
    for player_id, player_data in pairs(players) do
        local row = playerList:AddRow({
            player_data.name or "Unknown",
            tostring(player_data.ping or 0) .. "ms",
            player_data.status or "Connected"
        })
        
        row.player_id = player_id
    end
end

function UIManager.OnGameLoad()
    -- Отложенная инициализация UI после загрузки игры
    CreateTimer("UILoadDelay", 1000, function()
        UIManager.Initialize()
    end)
end

-- Экспорт функций глобально
ToggleMultiplayerMenu = UIManager.ToggleMultiplayerMenu
ShowMultiplayerMenu = UIManager.ShowMultiplayerMenu
HideMultiplayerMenu = UIManager.HideMultiplayerMenu

-- Регистрация обработчика загрузки игры
RegisterEventHandler("GAME_LOADED", UIManager.OnGameLoad)