-- state_sync.lua
local SyncManager = {
    entities = {},
    players = {},
    world_state = {}
}

function SyncManager.Initialize()
    CreateSyncThreads()
    RegisterSyncHandlers()
end

function CreateSyncThreads()
    -- Поток синхронизации позиций
    CreateThread("PositionSync", function()
        while IsServerRunning() do
            SyncAllPlayerPositions()
            Wait(50) -- 20 раз в секунду
        end
    end)
    
    -- Поток синхронизации состояния мира
    CreateThread("WorldStateSync", function()
        while IsServerRunning() do
            SyncWorldState()
            Wait(1000) -- 1 раз в секунду
        end
    end)
    
    -- Поток синхронизации инвентаря
    CreateThread("InventorySync", function()
        while IsServerRunning() do
            SyncPlayerInventories()
            Wait(200) -- 5 раз в секунду
        end
    end)
end

function SyncAllPlayerPositions()
    local positions = {}
    for player_id, player_data in pairs(SyncManager.players) do
        if IsPlayerOnline(player_id) then
            local x, y, z = GetPlayerPosition(player_id)
            positions[player_id] = {
                x = math.floor(x * 100) / 100, -- Округление для оптимизации
                y = math.floor(y * 100) / 100,
                z = math.floor(z * 100) / 100,
                rotation = GetPlayerRotation(player_id)
            }
        end
    end
    
    BroadcastToAllClients("SYNC_POSITIONS", positions)
end

function SyncWorldState()
    local world_data = {
        time = GetGameTime(),
        weather = GetCurrentWeather(),
        factions = GetAllFactionRelations(),
        squads = GetActiveSquadsData(),
        towns = GetTownStates()
    }
    
    SyncManager.world_state = world_data
    BroadcastToAllClients("SYNC_WORLD_STATE", world_data)
end

function SyncPlayerInventories()
    local inventory_data = {}
    
    for player_id, player_data in pairs(SyncManager.players) do
        if IsPlayerOnline(player_id) then
            inventory_data[player_id] = {
                items = GetPlayerInventory(player_id),
                money = GetPlayerMoney(player_id),
                equipment = GetPlayerEquipment(player_id),
                health = GetPlayerHealth(player_id),
                stats = GetPlayerStats(player_id)
            }
        end
    end
    
    BroadcastToAllClients("SYNC_INVENTORIES", inventory_data)
end

function HandlePlayerJoin(player_id, character_data)
    SyncManager.players[player_id] = {
        character_data = character_data,
        join_time = GetTime(),
        last_sync = GetTime()
    }
    
    -- Отправить новому игроку полное состояние мира
    SendToClient(player_id, "FULL_WORLD_SYNC", {
        world_state = SyncManager.world_state,
        players = GetAllPlayersData(),
        entities = GetRelevantEntities(player_id)
    })
    
    -- Уведомить других игроков
    BroadcastToAllClientsExcept(player_id, "PLAYER_JOINED", {
        player_id = player_id,
        character_data = character_data
    })
end

function HandlePlayerMovement(player_id, movement_data)
    if SyncManager.players[player_id] then
        SetPlayerPosition(
            player_id, 
            movement_data.x, 
            movement_data.y, 
            movement_data.z
        )
        SetPlayerRotation(player_id, movement_data.rotation)
        
        SyncManager.players[player_id].last_sync = GetTime()
    end
end

function RegisterSyncHandlers()
    RegisterNetworkHandler("PLAYER_MOVEMENT", HandlePlayerMovement)
    RegisterNetworkHandler("PLAYER_ACTION", HandlePlayerAction)
    RegisterNetworkHandler("INVENTORY_UPDATE", HandleInventoryUpdate)
    RegisterNetworkHandler("WORLD_INTERACTION", HandleWorldInteraction)
end

-- Запуск системы синхронизации
SyncManager.Initialize()